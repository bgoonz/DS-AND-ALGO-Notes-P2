# W8D4 - Networks

## [TCP/IP Model]

## [Binary and Hexidecimal Notation]

## [Internet Protocol]

## [Transport Protocols]

## [DNS and DNS Resolution]

## [Network Hardware]

## [EOD Review]

[TCP/IP Model]: ./tcp-ip-model.md
[Binary and Hexidecimal Notation]: ./binary-hexidecimal.md
[Internet Protocol]: ./internet-protocol.md
[Transport Protocols]: ./transport-protocols.md
[DNS and DNS Resolution]: ./dns.md
[Network Hardware]: ./hardware.md
[EOD Review]: ./eod.md