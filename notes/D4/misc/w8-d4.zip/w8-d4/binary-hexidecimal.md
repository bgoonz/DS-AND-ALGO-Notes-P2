## Binary and Hexidecimal Notation

### Convert Binary to Decimal:

![Convert Binary to Decimal]

## Convert Hexidecimal to Decimal:

![Convert Hexidecimal to Decimal]

[Convert Binary to Decimal]: ./convert-binary.png
[Convert Hexidecimal to Decimal]: ./convert-hexidecimal.png