------
------


## <span style="color: blue">Q:   --->*        This OSI layer is responsible for managing low-level protocols like WiFi and DSL         </span>

## <span style="color: red">A:   --------->          Physical       </span>


------
------



## <span style="color: blue">Q:   --->*         This layer in the OSI model is responsible for dealing with connections directly from one machine's network interface to another machine's network interface        </span>

## <span style="color: red">A:   --------->         Data link        </span>


------
------


## <span style="color: blue">Q:   --->*       This OSI layer includes information used by client side software          </span>

## <span style="color: red">A:   --------->        Application Layer         </span>


------
------


## <span style="color: blue">Q:   --->*        This OSI layer is where data gets translatable into a presentable format. This includes data compression, encryption, image formats, etc         </span>

## <span style="color: red">A:   --------->        Presentation Layer         </span>


------
------


## <span style="color: blue">Q:   --->*        This OSI layer includes protocols responsible for authentication and data continuity (i.e. RPC)         </span>

## <span style="color: red">A:   --------->           Session      </span>


------
------



## <span style="color: blue">Q:   --->*         These three OSI model layers make up the Application layer of the TCP/IP model        </span>

## <span style="color: red">A:   --------->         Application, Presentation, Session        </span>


------
------


## <span style="color: blue">Q:   --->*         This OSI Layer utilizes transport protocols in order to provide data integrity and connectivity (TCP and UDP for example)        </span>

## <span style="color: red">A:   --------->       Transport          </span>


------
------


## <span style="color: blue">Q:   --->*          This OSI Layer manages connections between remote networks (i.e. IP)       </span>

## <span style="color: red">A:   --------->           Network layer      </span>


------
------



## <span style="color: blue">Q:   --->*       This OSI layer deals with connections directly between two machine's network interfaces.  This layer is mostly used by machines in a local network (i.e. Ethernet)          </span>

## <span style="color: red">A:   --------->          Data Link       </span>


------
------



## <span style="color: blue">Q:   --->*          This OSI layer translates raw electrical signals to data bits. (i.e. WiFi 802.11 or DSL)       </span>

## <span style="color: red">A:   --------->           Physical Layer      </span>


------
------


## <span style="color: blue">Q:   --->*                 </span>

## <span style="color: red">A:   --------->                 </span>


------
------


## <span style="color: blue">Q:   --->*                 </span>

## <span style="color: red">A:   --------->                 </span>


------
------

