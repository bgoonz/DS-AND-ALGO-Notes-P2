let fib = (n) => (n === 1 || n === 2 ? 1 : fib(n - 1) + fib(n - 2));

// let fibonacci = (40) => {
//   if (n === 1 || n === 2) return 1;
//   return fibonacci(n - 1) + fibonacci(n - 2);
// };
