let XOR = function (a, b) {
  if ((a || b) && !(a && b)) {
    return true;
  }
};
