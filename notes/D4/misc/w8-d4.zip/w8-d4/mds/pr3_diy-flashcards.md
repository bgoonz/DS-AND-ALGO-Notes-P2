# DIY Flashcards Exercise
________________________________________________________________________________
<!-- @import "[TOC]" {cmd="toc" depthFrom=2 depthTo=6 orderedList=false} -->

<!-- code_chunk_output -->



<!-- /code_chunk_output -->
________________________________________________________________________________

There is a lot of terminology and knowledge in today's lessons. These aren't
skills that you can necessarily apply. However, the body of knowledge is
essential to understand how networking works both in ideal and practical senses.

Today, it's up to you to make your own flashcards for studying. You can make
then in your pair and share the Anki files. Use them to study because this will
likely be on your assessment and in some interviews.
