# Network Models Learning Objectives

**The objective of this lesson** is for you to get a basic understanding of
network models. This lesson is relevant because any network-connected software
that you write will implementations of these models to communicate with other
computers. Questions about network models are popular interviewing topics, too.

When you finish, you should be able to

1. Describe the structure and function of network models from the perspective of
a developer.
