# code-snippets

This is a personal repository of useful helper functions that may become useful in
projects or in understanding how to approach problems in the future.
